/**
 * Help determine the encoding of a file by displaying it in various
 * encodings.
 * Version 1.0, 2007-07-04 initial
 * Version 1.1, 2008-04-01 display build number, increase size of sample
 */
package com.mindprod.encodingrecogniser;

import com.mindprod.common11.Build;
import com.mindprod.common11.FontFactory;
import com.mindprod.common11.VersionCheck;
import com.mindprod.common13.CMPAboutJBox;
import com.mindprod.common13.Common13;
import com.mindprod.common13.HybridJ;
import com.mindprod.common13.JEButton;

import javax.swing.*;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.AccessControlException;
import java.util.Set;
import java.util.SortedMap;

/**
 * @author Roedy Green,  copyright (c) 2007-2009Canadian Mind Products
 * @version 1.1, 2008-04-01 display build number, increase size of sample.
 */
@SuppressWarnings( { "FieldCanBeLocal" } )
public final class EncodingRecogniser extends JApplet
    {
    // ------------------------------ FIELDS ------------------------------

    /**
     * true if want extra debugging info.
     *
     * @noinspection WeakerAccess
     */
    static final boolean DEBUGGING = false;

    /**
     * height of applet box in pixels. has no effect on application width. Does not include surrounding frame.  Height
     * to use in &lt;applet tag.
     *
     * @noinspection UnusedDeclaration
     */
    private static final int APPLET_HEIGHT = 528;

    /**
     * Width of applet box in pixels, has no effect on application width. Height to use in &lt;applet tag.
     *
     * @noinspection UnusedDeclaration
     */
    private static final int APPLET_WIDTH = 636;

    /**
     * maximum number of bytes in the file to read as a sample
     */
    private static final int MAX_BYTES_TO_SAMPLE = 1024 * 1024;

    /**
     * maximum number of bytes in the file to display in hex
     */
    private static final int MAX_HEX_BYTES_TO_SAMPLE = 22;

    /**
     * maximum number of chars in the file to display as hex
     */
    private static final int MAX_HEX_CHARS_TO_SAMPLE = 12;

    /**
     * background colour, pale green to match website
     */
    private static final Color BODY_BACKGROUND = Build.BLEND_BACKGROUND;

    /**
     * background colour for instructions.  Default grey is too dark
     */
    private static final Color INSTRUCTIONS_BACKGROUND = new Color( 0xf8f8f8 );

    /**
     * instruction normal color
     */
    private static final Color INSTRUCTIONS_FOREGROUND = new Color( 0x339911 );

    /**
     * foreground colour for labels
     */
    private static final Color LABEL_FOREGROUND = new Color( 0x0000b0 );

    /**
     * for titles
     */
    private static final Color TITLE_FOREGROUND = new Color( 0xdc143c );

    /**
     * instructions font
     */
    private static final Font INSTRUCTIONS_FONT =
            FontFactory.build( "Dialog", Font.PLAIN, 12 );

    /**
     * for for title second line
     */
    private static final Font TITLE2_FONT = FontFactory.build( "Dialog", Font.PLAIN, 14 );

    /**
     * title font
     */
    private static final Font TITLE_FONT = FontFactory.build( "Dialog", Font.BOLD, 15 );

    /**
     * non-displaying copyright.
     *
     * @noinspection UnusedDeclaration
     */
    public static final String EMBEDDED_COPYRIGHT =
            "copyright (c) 1998-2009 Roedy Green, Canadian Mind Products, http://mindprod.com";

    private static final String RELEASE_DATE = "2008-04-01";

    private static final String TITLE_STRING = "Encoding Recogniser";

    private static final String VERSION_STRING = "1.1";

    // table to convert a nibble to a hex char.
    private static final char[] hexChar = {
            '0',
            '1',
            '2',
            '3',
            '4',
            '5',
            '6',
            '7',
            '8',
            '9',
            'a',
            'b',
            'c',
            'd',
            'e',
            'f' };

    /**
     * about button
     */
    private JButton about;

    /**
     * choose a file to display
     */
    private JButton chooseFile;

    /**
     * chose which encoding to display
     */
    private JComboBox chooseEncoding;

    /**
     * label for encoding
     */
    private JLabel encodingLabel;

    /**
     * label for file name
     */
    private JLabel fileLabel;

    /**
     * hex bytes label
     */
    private JLabel hexByteLabel;

    /**
     * hex char label
     */
    private JLabel hexCharLabel;

    /**
     * short instructions for use
     */
    private JLabel instructions;

    /**
     * Applet Title
     */
    private JLabel title;

    /**
     * title, second line
     */
    private JLabel title2;

    /**
     * Scroller fro displayFileContents.
     */
    private JScrollPane scroller;

    /**
     * file displayed as if it were encoding in the chosen encoding
     */
    private JTextArea displayFileContents;

    /**
     * name of file we are trying to figure out encoding for.
     */
    private JTextField fileName;

    /**
     * first few untranslated bytes of file in hex
     */
    private JTextField hexBytes;

    /**
     * first few translated chars of file in hex
     */
    private JTextField hexChars;

    /**
     * chars after bytes from file decoded
     */
    private String translatedBytes;

    /**
     * Raw sample from the file to use in display sample
     */
    private byte[] rawByteSample;

    // -------------------------- PUBLIC INSTANCE  METHODS --------------------------
    /**
     * usual JApplet init
     */
    public void init()
        {
        // need signed to read file
        if ( !VersionCheck.isJavaVersionOK( 1, 5, 0, this ) )
            {
            // effectively abort
            return;
            }
        Common13.setLaf();
        Container contentPane = this.getContentPane();
        contentPane.setLayout( new GridBagLayout() );
        contentPane.setBackground( BODY_BACKGROUND );

        title = new JLabel( TITLE_STRING + " " + VERSION_STRING );
        title.setFont( TITLE_FONT );
        title.setForeground( TITLE_FOREGROUND );

        title2 = new JLabel(
                "released:" +
                RELEASE_DATE +
                " build:" +
                Build.BUILD_NUMBER );
        title2.setFont( TITLE2_FONT );
        title2.setForeground( TITLE_FOREGROUND );

        about = new JEButton( "About" );
        about.setToolTipText( "About " + TITLE_STRING + " " + VERSION_STRING );

        chooseFile = new JEButton( "Choose File" );
        chooseFile.setToolTipText( "Choose a file to study" );

        fileName = new JTextField();
        fileName.setEditable( false );
        fileName.setForeground( Color.RED );

        /** populate with all supported exceptions */
        SortedMap<String, Charset> sm = Charset.availableCharsets();
        Set<String> encodings = sm.keySet();
        chooseEncoding =
                new JComboBox( encodings.toArray( new String[encodings.size()] ) );

        try
            {
            // avoid looking at restricted system property.
            chooseEncoding.setSelectedItem( Charset.
                    defaultCharset().
                    name() );
            }
        catch ( AccessControlException e )
            {
            chooseEncoding.setSelectedIndex( 0 );
            }

        fileLabel = new JLabel( "file to check", JLabel.LEFT );
        fileLabel.setForeground( LABEL_FOREGROUND );

        encodingLabel = new JLabel( "encoding candidate", JLabel.RIGHT );
        encodingLabel.setForeground( LABEL_FOREGROUND );

        hexByteLabel = new JLabel( "raw hex bytes" );
        hexByteLabel.setForeground( LABEL_FOREGROUND );

        hexCharLabel = new JLabel( "decoded hex chars" );
        hexCharLabel.setForeground( LABEL_FOREGROUND );

        hexBytes = new JTextField();
        hexBytes.setEditable( false );

        hexChars = new JTextField();
        hexChars.setEditable( false );

        displayFileContents = new JTextArea();
        displayFileContents.setEditable( false );
        scroller =
                new JScrollPane( displayFileContents,
                        JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );

        instructions =
                new JLabel(
                        "Choose a file, then try various encodings till you find an encoding that displays it properly.",
                        JLabel.CENTER );
        instructions.setFont( INSTRUCTIONS_FONT );
        instructions.setBackground( INSTRUCTIONS_BACKGROUND );
        instructions.setForeground( INSTRUCTIONS_FOREGROUND );

        layoutComponents( contentPane );
        hookComponents();
        }

    // -------------------------- STATIC METHODS --------------------------

    /**
     * Fast convert a byte array to a hex string with possible leading zero.
     *
     * @param b      array of bytes you want to convert to hex.
     * @param length how many bytes you wanted convented to byte.
     *
     * @return hex equivalent of the bytes
     */
    private static String toHexString( byte[] b, int length )
        {
        StringBuilder sb = new StringBuilder( length * 3 );
        for ( int i = 0; i < length; i++ )
            {
            if ( i != 0 )
                {
                sb.append( ' ' );
                }
            // look up high nibble char
            sb.append( hexChar[ ( b[ i ] & 0xf0 ) >>> 4 ] );

            // look up low nibble char
            sb.append( hexChar[ b[ i ] & 0x0f ] );
            }
        return sb.toString();
        }

    /**
     * Fast convert a String to a hex string with possible leading zero.
     *
     * @param b      array of chars you want to convert to hex.
     * @param length how many chars you wanted convented to byte.
     *
     * @return hex equivalent of the bytes
     */
    private static String toHexString( String b, int length )
        {
        StringBuilder sb = new StringBuilder( length * 5 );
        for ( int i = 0; i < length; i++ )
            {
            if ( i != 0 )
                {
                sb.append( ' ' );
                }
            // work high order to low
            final int c = b.charAt( i );
            sb.append( hexChar[ ( c & 0xf000 ) >>> 12 ] );
            sb.append( hexChar[ ( c & 0xf00 ) >>> 8 ] );
            sb.append( hexChar[ ( c & 0xf0 ) >>> 4 ] );
            sb.append( hexChar[ c & 0x0f ] );
            }
        return sb.toString();
        }

    // -------------------------- OTHER METHODS --------------------------

    /**
     * classify sample, looking for BOM
     */
    private void classifyBOM()
        {
        if ( rawByteSample.length < 4 )
            {
            return;
            }

        int b0 = rawByteSample[ 0 ] & 0xff;

        int b1 = rawByteSample[ 1 ] & 0xff;

        int b2 = rawByteSample[ 2 ] & 0xff;

        int b3 = rawByteSample[ 3 ] & 0xff;

        if ( b0 == 0xef && b1 == 0xbb && b2 == 0xbf )

            {
            instructions.setText( "Hint: the file starts with a UTF-8 BOM." );
            }

        else if ( b0 == 0xfe && b1 == 0xff )
            {
            instructions.setText( "Hint: the file starts with a UTF-16BE BOM." );
            }

        else if ( b0 == 0xff && b1 == 0xfe )

                {
                instructions.setText( "Hint: the file starts with a UTF-16LE BOM." );
                }

            else if ( b0 == 0x00 && b1 == 0x00 && b2 == 0xfe && b3 == 0xff )

                    {
                    instructions.setText( "Hint: the file starts with a UTF-32BE BOM." );
                    }

                else if ( b0 == 0xff && b1 == 0xfe && b2 == 0x00 && b3 == 0x00 )

                        {
                        instructions.setText( "Hint: the file starts with a UTF-32LE BOM." );
                        }

                    else

                        {
                        instructions.setText( "Hint: the file has no Unicode BOM." );
                        }
        }

    /**
     * display the sample raw bytes from the file with the current encoding
     */
    private void displaySampleWithCurrentEncoding()
        {
        String encodingName = ( String ) chooseEncoding.getSelectedItem();
        // Use String constructor to decode bytes to String.
        // We do this only once, so no need to bother with nio.
        try
            {
            int hexByteSampleSize =
                    Math.min( rawByteSample.length, MAX_HEX_BYTES_TO_SAMPLE );
            hexBytes.setText( toHexString( rawByteSample, hexByteSampleSize ) );

            translatedBytes = new String( rawByteSample, encodingName );

            int hexCharSampleSize =
                    Math.min( translatedBytes.length(), MAX_HEX_CHARS_TO_SAMPLE );
            hexChars.setText( toHexString( translatedBytes,
                    hexCharSampleSize ) );

            displayFileContents.setText( translatedBytes );
            }
        catch ( UnsupportedEncodingException e )
            {
            instructions.setText(
                    "Unsupported encoding.  Please report program bug." );
            }
        }

    /**
     * register listeners for various components.
     */
    private void hookComponents()
        {
        about.addActionListener( new ActionListener()
        {
        public void actionPerformed( ActionEvent e )
            {
            // open aboutbox frame
            new CMPAboutJBox( TITLE_STRING,
                    VERSION_STRING,
                    "Helps you determine a file's encoding.",
                    "",
                    "freeware",
                    RELEASE_DATE,
                    2007,
                    "Roedy Green",
                    "ENCODINGRECOGNISER",
                    "1.5" );
            }
        } );
        // what to do when user selects a new file.
        chooseFile.addActionListener( new ActionListener()
        {
        public void actionPerformed( ActionEvent e )
            {
            JFileChooser fc = new JFileChooser();
            // No filter. No suggested starting point.

            switch ( fc.showOpenDialog( EncodingRecogniser.this ) )
                {
                case JFileChooser.APPROVE_OPTION:
                    File file = fc.getSelectedFile();

                    try
                        {
                        fileName.setText( file.getCanonicalPath() );
                        }
                    catch ( IOException evt )
                        {
                        fileName.setText( file.getAbsolutePath() );
                        }
                    // get text from the file.

                    try
                        {
                        int sampleSize =
                                ( int ) Math.min( file.length(),
                                        MAX_BYTES_TO_SAMPLE );

                        // O P E N
                        FileInputStream fis = new FileInputStream( file );

                        // R E A D
                        byte[] b = new byte[sampleSize];
                        // -1 means eof.
                        // You don't necessarily get all you ask for in one read.
                        // You get what's immediately available.
                        int bytesRead = fis.read( b,
                                0
                                /* offset in ba */,
                                sampleSize
                                /* bytes to read */ );
                        if ( bytesRead != sampleSize )
                            {
                            throw new IOException( "cannot read file" );
                            }
                        rawByteSample = b;
                        // C L O S E
                        fis.close();
                        displaySampleWithCurrentEncoding();
                        classifyBOM();
                        }
                    catch ( IOException e2 )
                        {
                        fileName.setText( "Cannot read "
                                          + fileName.getText() );
                        }

                    break;
                case JFileChooser.CANCEL_OPTION:
                case JFileChooser.ERROR_OPTION:
                    break;
                default:
                }
            }
        } );
        chooseEncoding.addItemListener( new ItemListener()
        {
        /**
         * Called whenever the value of the encoding changes. W
         *
         * @param e the event that characterizes the change.
         */
        public void itemStateChanged( ItemEvent e )
            {
            displaySampleWithCurrentEncoding();
            }
        } );
        }

    /**
     * layout the components
     *
     * @param contentPane contentpane of the JApplet
     */
    private void layoutComponents( Container contentPane )
        {
        // --0--------1-----------------2-
        // 0 title  ------------------ about
        // 1 title2 ------------------ about
        // 2 ----------"file"------"encoding"
        // 3 choose--  file-------- encoding
        // 4 "hex bytes"    --- hexbytes----
        // 5 "hex chars"    --- hexChars----
        // 6 ---file contents---------------
        // 7 ---- instructions --------------

        // x y w h wtx wty anchor fill T L B R padx pady
        contentPane.add( title,
                new GridBagConstraints( 0,
                        0,
                        2,
                        1,
                        0.0,
                        0.0,
                        GridBagConstraints.WEST,
                        GridBagConstraints.NONE,
                        new Insets( 10, 10, 0, 10 ),
                        0,
                        0 ) );
        contentPane.add( title2,
                new GridBagConstraints( 0,
                        1,
                        2,
                        1,
                        0.0,
                        0.0,
                        GridBagConstraints.WEST,
                        GridBagConstraints.NONE,
                        new Insets( 0, 10, 5, 10 ),
                        0,
                        0 ) );

        contentPane.add( about,
                new GridBagConstraints( 2,
                        0,
                        2,
                        1,
                        0.0,
                        0.0,
                        GridBagConstraints.EAST,
                        GridBagConstraints.NONE,
                        new Insets( 10, 10, 5, 10 ),
                        0,
                        0 ) );

        contentPane.add( chooseFile,
                new GridBagConstraints( 0,
                        3,
                        1,
                        1,
                        0.0,
                        0.0,
                        GridBagConstraints.WEST,
                        GridBagConstraints.NONE,
                        new Insets( 5, 10, 5, 10 ),
                        0,
                        0 ) );
        contentPane.add( fileLabel,
                new GridBagConstraints( 1,
                        2,
                        1,
                        1,
                        0.0,
                        0.0,
                        GridBagConstraints.WEST,
                        GridBagConstraints.NONE,
                        new Insets( 5, 0, 5, 10 ),
                        0,
                        0 ) );

        contentPane.add( encodingLabel,
                new GridBagConstraints( 2,
                        2,
                        1,
                        1,
                        0.0,
                        0.0,
                        GridBagConstraints.EAST,
                        GridBagConstraints.NONE,
                        new Insets( 5, 5, 5, 10 ),
                        0,
                        0 ) );

        contentPane.add( fileName,
                new GridBagConstraints( 1,
                        3,
                        1,
                        1,
                        50.0,
                        0.0,
                        GridBagConstraints.WEST,
                        GridBagConstraints.HORIZONTAL,
                        new Insets( 5, 0, 5, 10 ),
                        250
                        /** allow room for new filename */,
                        0 ) );

        contentPane.add( chooseEncoding,
                new GridBagConstraints( 2,
                        3,
                        1,
                        1,
                        0.0,
                        0.0,
                        GridBagConstraints.EAST,
                        GridBagConstraints.NONE,
                        new Insets( 5, 10, 5, 10 ),
                        0,
                        0 ) );

        contentPane.add( hexByteLabel,
                new GridBagConstraints( 0,
                        4,
                        1,
                        1,
                        0.0,
                        0.0,
                        GridBagConstraints.EAST,
                        GridBagConstraints.NONE,
                        new Insets( 5, 10, 5, 10 ),
                        0,
                        0 ) );

        contentPane.add( hexBytes,
                new GridBagConstraints( 1,
                        4,
                        2,
                        1,
                        0.0,
                        0.0,
                        GridBagConstraints.EAST,
                        GridBagConstraints.HORIZONTAL,
                        new Insets( 5, 0, 5, 10 ),
                        250,
                        0 ) );

        contentPane.add( hexCharLabel,
                new GridBagConstraints( 0,
                        5,
                        1,
                        1,
                        0.0,
                        0.0,
                        GridBagConstraints.EAST,
                        GridBagConstraints.NONE,
                        new Insets( 5, 10, 5, 10 ),
                        0,
                        0 ) );
        contentPane.add( hexChars,
                new GridBagConstraints( 1,
                        5,
                        2,
                        1,
                        0.0,
                        0.0,
                        GridBagConstraints.EAST,
                        GridBagConstraints.HORIZONTAL,
                        new Insets( 5, 0, 5, 10 ),
                        250,
                        0 ) );

        contentPane.add( scroller,
                new GridBagConstraints( 0,
                        6,
                        3,
                        1,
                        100.0,
                        100.0,
                        GridBagConstraints.CENTER,
                        GridBagConstraints.BOTH,
                        new Insets( 5, 10, 5, 10 ),
                        0,
                        0 ) );
        contentPane.add( instructions,
                new GridBagConstraints( 0,
                        7,
                        3,
                        1,
                        0.0,
                        0.0,
                        GridBagConstraints.CENTER,
                        GridBagConstraints.BOTH,
                        new Insets( 5, 10, 10, 10 ),
                        0,
                        0 ) );
        }

    // --------------------------- main() method ---------------------------

    /**
     * Allow this Applet to run as as application as well.
     *
     * @param args command line arguments ignored.
     */
    public static void main( String args[] )
        {
        HybridJ.fireup( new EncodingRecogniser(),
                TITLE_STRING + " " + VERSION_STRING,
                APPLET_WIDTH,
                APPLET_HEIGHT );
        }// end main
    }
