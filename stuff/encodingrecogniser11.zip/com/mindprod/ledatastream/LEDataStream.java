/**
 * LEDataStream.java
 * copyright (c) 1998-2009 Roedy Green, Canadian Mind Products
 * http://mindprod.com
 * Version History
 * 1.0 1998-01-6
 * 1.1 1998-01-07- officially implements DataInput
 * 1.2 1998-01-09- add LERandomAccessFile
 * 1.3 1998-08-27
 * 1.4 1998-11-10 - add new address and phone.
 * 1.5 1999-10-08- use com.mindprod.ledatastream package name.
 *  1.6 2005-06-13 - made  * readLine deprecated Very similar to DataInputStream
 * except it reads little-endian instead of big-endian binary data. We can't extend
 * 1.8 2007-05-24 - add pad, icon, pass Intellij inspector.
 *
 *
 * Tests Little Endian LEDataInputStream and LEDataOutputStream and demonstrates
 * the use of its methods. Output should look like this: 44 -1 a -249
 * -123456789012 -649 -749 true 3.14 4.14 echidna kangaroo u dingo Then
 * repeated.
 */
package com.mindprod.ledatastream;

/**
 * dummy not used
 *
 * @author Roedy Green
 * @version 1.8 2007-05-24
 */
public final class LEDataStream
    {
    // ------------------------------ FIELDS ------------------------------

    /**
     * undisplayed copyright notice
     *
     * @noinspection UnusedDeclaration
     */
    private static final String EMBEDDED_COPYRIGHT =
            "copyright (c) 1999-2009 Roedy Green, Canadian Mind Products, http://mindprod.com";

    /**
     * @noinspection UnusedDeclaration
     */
    private static final String RELEASE_DATE = "2007-05-24";

    /**
     * embedded version string.
     *
     * @noinspection UnusedDeclaration
     */
    private static final String VERSION_STRING = "1.8";

    // --------------------------- main() method ---------------------------

    /**
     * Dummy not used.
     *
     * @param args not used
     *
     * @noinspection EmptyMethod
     */
    public static void main( String[] args )
        {
        }
    }
