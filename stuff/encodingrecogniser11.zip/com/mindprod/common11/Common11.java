package com.mindprod.common11;

/**
 * dummy not used
 *
 * @version 2.1 2008-12-16 new methods in BigDate
 */
public final class Common11
    {
    // --------------------------- main() method ---------------------------

    /**
     * test harness
     *
     * @param args not used
     */
    public static void main( String[] args )
        {
        }
    }
