package com.mindprod.common11;

import java.awt.Color;

/**
 * @author Roedy Green, Canadian Mind Products
 * @version 1.0, 19-Sep-2007 Created with IntelliJ IDEA.
 */
public class Build
    {
    // ------------------------------ FIELDS ------------------------------

    /**
     * incremented for each microrelease even when version numbers are not changed.  Global to all apps.
     */
    public static final int BUILD_NUMBER = 9250;

    /**
     * current year, used for copyright
     */
    public static final int THIS_COPYRIGHT_YEAR = Misc.thisYear();

    /**
     * colour to let app blend with CMP background
     */
    public static final Color BLEND_BACKGROUND = new Color( 0xf3fff6 );
    /**
     * name of the code signing cert without .cer
     */
    public static final String MINDPRODCERT = "mindprodcert2009dsa";
    }
