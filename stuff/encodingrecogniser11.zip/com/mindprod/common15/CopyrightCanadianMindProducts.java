// this code lives in a file called CopyrightCanadianMindproducts.java
package com.mindprod.common15;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * embedded copyright
 */
@Documented
@Retention( RetentionPolicy.RUNTIME )
        @interface CopyrightCanadianMindProducts
    {
    // ------------------------------ FIELDS ------------------------------

    /**
     * copyright to embed via annotations so it is embedded in all classes that reference it
     */
    String defaultCopyright =
            "copyright (c) 1998-2009 Roedy Green, "
            + "Canadian Mind Products, http://mindprod.com";
    // -------------------------- PUBLIC INSTANCE  METHODS --------------------------

    /**
     * get value of this annotation
     *
     * @return the copyright string
     */
    String value() default defaultCopyright;
    }
