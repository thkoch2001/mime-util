package com.mindprod.common15;

/**
 * dummy not used
 *
 * @author Roedy Green
 * @version 1.2 2008-09-09 initial public release
 */
public final class Common15
    {
    // --------------------------- main() method ---------------------------

    /**
     * TEST harness
     *
     * @param args not used
     */
    public static void main( String[] args )
        {
        }
    }
