package com.mindprod.common13;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * methods common to all Swing-using programs
 *
 * @version 1.3 2008-11-12 add JDK version to About box
 * @noinspection EmptyCatchBlock
 */
public final class Common13
    {
    // ------------------------------ FIELDS ------------------------------

    private static final boolean DEBUGGING = false;
    // -------------------------- PUBLIC STATIC METHODS --------------------------

    /**
     * set the look and feel for a Swing App.
     * Use Nimbus if available, failing that cross platform metal, failing that the default.
     */
    public static void setLaf()
        {
        if ( System.getProperty( "os.name", "unknown" ).equals( "Mac OS X" ) )
            {
            try
                {
                UIManager.setLookAndFeel( UIManager.getSystemLookAndFeelClassName() );
                return;
                }
            catch ( UnsupportedLookAndFeelException e )
                {
                if ( DEBUGGING )
                    {
                    System.err.println( "system L&F failed 1" );
                    }
                }
            catch ( IllegalAccessException e )
                {
                if ( DEBUGGING )
                    {
                    System.err.println( "system L&F failed 2" );
                    }
                }
            catch ( InstantiationException e )
                {
                if ( DEBUGGING )
                    {
                    System.err.println( "system L&F failed 3" );
                    }
                }
            catch ( ClassNotFoundException e )
                {
                if ( DEBUGGING )
                    {
                    System.err.println( "system L&F failed 4" );
                    }
                }
            }

        try
            {
            // Avoid new com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel() to avoid the dreaded
            // NoClassDefFoundError
            UIManager.setLookAndFeel( "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel" );
            return;
            }
        catch ( UnsupportedLookAndFeelException e )
            {
            if ( DEBUGGING )
                {
                System.err.println( "nimbus L&F failed 1" );
                }
            }
        catch ( IllegalAccessException e )
            {
            if ( DEBUGGING )
                {
                System.err.println( "nimbus L&F failed 2" );
                }
            }
        catch ( InstantiationException e )
            {
            if ( DEBUGGING )
                {
                System.err.println( "nimbus L&F failed 3" );
                }
            }
        catch ( ClassNotFoundException e )
            {
            if ( DEBUGGING )
                {
                System.err.println( "nimbus L&F failed 4" );
                }
            }

        try
            {
            UIManager.setLookAndFeel( UIManager.getCrossPlatformLookAndFeelClassName() );
            }
        catch ( UnsupportedLookAndFeelException e )
            {
            if ( DEBUGGING )
                {
                System.err.println( "metal L&F failed 1" );
                }
            }
        catch ( IllegalAccessException e )
            {
            if ( DEBUGGING )
                {
                System.err.println( "metal L&F failed 2" );
                }
            }
        catch ( InstantiationException e )
            {
            if ( DEBUGGING )
                {
                System.err.println( "metal L&F failed 3" );
                }
            }
        catch ( ClassNotFoundException e )
            {
            if ( DEBUGGING )
                {
                System.err.println( "metal L&F failed 4" );
                }
            }

        // give up. leave original L&F in place.
        }

    // --------------------------- main() method ---------------------------

    /**
     * test harness
     *
     * @param args not used
     *
     * @noinspection EmptyMethod
     */
    public static void main( String[] args )
        {
        // dummy
        }
    }
